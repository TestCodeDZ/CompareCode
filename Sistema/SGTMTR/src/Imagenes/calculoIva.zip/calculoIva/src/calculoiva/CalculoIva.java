package calculoiva;
import java.util.Scanner; 

/*
 * @author tutorias.co
 */

public class CalculoIva{

    /**
     * se crea el canal de entrada de datos con scanner
     */
    static Scanner entrada = new Scanner(System.in);
    static double valor;
    
    public static void main(String[] args) {
        // se instancia la clase Iva y se invocan los metodos
        System.out.print("Favor ingresar valor: ");
        Iva solucion = new Iva(entrada.nextDouble());
        solucion.calcularIva();
        solucion.calcularValorArticulo();
        solucion.mostrarResultado();
    }
}

// clase iva
class Iva{
    double precio, valorIva, valorArticulo;
    Iva(double valor){
        precio = valor;        
    }
    public void calcularIva(){
        valorIva = precio * .16;
    }
    public void calcularValorArticulo(){
        valorArticulo = precio + valorIva;
    }
    public void mostrarResultado(){
        System.out.println("\nIva = " + valorIva + "\nValor articulo = "+ valorArticulo);
    }
    public void mostrarResultadoGrafico(){
        javax.swing.JOptionPane.showMessageDialog(null,"\nIva = " + valorIva + "\nValor articulo = "+ valorArticulo);
    }
}
// clase iva